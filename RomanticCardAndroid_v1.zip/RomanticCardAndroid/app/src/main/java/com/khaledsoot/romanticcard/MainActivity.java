package com.khaledsoot.romanticcard;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText fromInput, toInput, messageInput;
    private CardPreview cardPreview;
    private Bitmap selectedPhoto;
    private static final int PICK_IMAGE = 501;
    private int themeIndex = 0;
    private final int[][] palettes = {
            {Color.rgb(92, 12, 43), Color.rgb(205, 54, 93)},
            {Color.rgb(70, 32, 86), Color.rgb(181, 104, 160)},
            {Color.rgb(25, 35, 67), Color.rgb(113, 77, 137)},
            {Color.rgb(115, 48, 34), Color.rgb(220, 139, 94)}
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(91, 15, 47));
        getWindow().setNavigationBarColor(Color.rgb(48, 13, 29));
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(255, 246, 249));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(28));
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(page);

        TextView brand = new TextView(this);
        brand.setText("Khaled Soot  •  يقدم لكم");
        brand.setTextColor(Color.rgb(153, 63, 91));
        brand.setTextSize(13);
        brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());

        TextView title = new TextView(this);
        title.setText("💌 البطاقة الرومانسية");
        title.setTextColor(Color.rgb(126, 24, 60));
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(4));
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("اصنع بطاقة حب تحمل كلماتك ومشاعرك");
        subtitle.setTextColor(Color.rgb(130, 103, 113));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, matchWrap());

        cardPreview = new CardPreview();
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(-1, dp(300));
        previewParams.setMargins(0, dp(18), 0, dp(18));
        page.addView(cardPreview, previewParams);

        addLabel(page, "اسم المرسل");
        fromInput = addInput(page, "اكتب اسمك", "");
        addLabel(page, "إلى من تهدي البطاقة؟");
        toInput = addInput(page, "اسم الحبيب أو الحبيبة", "");
        addLabel(page, "رسالتك الرومانسية");
        messageInput = addInput(page, "اكتب كلماتك الجميلة هنا...", "");
        messageInput.setMinLines(3);
        messageInput.setGravity(Gravity.TOP | Gravity.RIGHT);

        Button photo = makeButton("اختيار صورة من الهاتف  🖼", Color.rgb(116, 72, 120));
        photo.setOnClickListener(v -> pickPhoto());
        page.addView(photo, buttonParams());

        Button removePhoto = makeButton("إزالة الصورة", Color.rgb(135, 105, 115));
        removePhoto.setOnClickListener(v -> { selectedPhoto = null; refreshCard(); Toast.makeText(this, "تمت إزالة الصورة", Toast.LENGTH_SHORT).show(); });
        page.addView(removePhoto, buttonParams());

        TextWatcher watcher = new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { refreshCard(); }
            public void afterTextChanged(Editable e) {}
        };
        fromInput.addTextChangedListener(watcher);
        toInput.addTextChangedListener(watcher);
        messageInput.addTextChangedListener(watcher);

        TextView paletteLabel = new TextView(this);
        paletteLabel.setText("اختر لون البطاقة");
        paletteLabel.setTextColor(Color.rgb(91, 42, 59));
        paletteLabel.setTextSize(15);
        paletteLabel.setTypeface(null, Typeface.BOLD);
        paletteLabel.setPadding(0, dp(16), 0, dp(8));
        page.addView(paletteLabel);

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        int[] swatches = {Color.rgb(177, 35, 82), Color.rgb(153, 83, 153), Color.rgb(52, 67, 115), Color.rgb(185, 104, 65)};
        for (int i = 0; i < swatches.length; i++) {
            final int index = i;
            Button colorButton = new Button(this);
            colorButton.setText(new String[]{"وردي", "بنفسجي", "ليلي", "دافئ"}[i]);
            colorButton.setTextColor(Color.WHITE);
            colorButton.setTextSize(12);
            colorButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(swatches[i]));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(88), dp(44));
            cp.setMargins(dp(4), 0, dp(4), 0);
            colors.addView(colorButton, cp);
            colorButton.setOnClickListener(v -> { themeIndex = index; refreshCard(); });
        }
        hsv.addView(colors);
        page.addView(hsv);

        Button update = makeButton("تحديث معاينة البطاقة", Color.rgb(130, 34, 70));
        update.setOnClickListener(v -> refreshCard());
        page.addView(update, buttonParams());

        Button save = makeButton("حفظ البطاقة في الصور  ⬇", Color.rgb(177, 45, 91));
        save.setOnClickListener(v -> saveCard());
        page.addView(save, buttonParams());

        Button share = makeButton("مشاركة البطاقة  ↗", Color.rgb(68, 135, 99));
        share.setOnClickListener(v -> shareCard());
        page.addView(share, buttonParams());

        TextView footer = new TextView(this);
        footer.setText("صُنعت بكل حب ❤️  |  Khaled Soot");
        footer.setGravity(Gravity.CENTER);
        footer.setTextColor(Color.rgb(148, 103, 119));
        footer.setTextSize(12);
        footer.setPadding(0, dp(20), 0, 0);
        page.addView(footer);

        setContentView(scroll);
        refreshCard();
    }

    private void addLabel(LinearLayout parent, String value) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextColor(Color.rgb(91, 42, 59));
        label.setTextSize(14);
        label.setTypeface(null, Typeface.BOLD);
        label.setPadding(0, dp(10), 0, dp(6));
        parent.addView(label);
    }

    private EditText addInput(LinearLayout parent, String hint, String value) {
        EditText input = new EditText(this);
        input.setText(value);
        input.setHint(hint);
        input.setTextSize(15);
        input.setSingleLine(false);
        input.setPadding(dp(12), dp(10), dp(12), dp(10));
        input.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        input.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(205, 155, 173)));
        parent.addView(input, matchWrap());
        return input;
    }

    private Button makeButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, dp(8), 0, 0);
        return p;
    }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private void pickPhoto() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, PICK_IMAGE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try {
                Uri uri = data.getData();
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
                try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
                    selectedPhoto = BitmapFactory.decodeStream(in);
                }
                refreshCard();
                Toast.makeText(this, "تم اختيار الصورة ❤️", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "تعذر فتح الصورة", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void refreshCard() {
        if (cardPreview != null) {
            cardPreview.invalidate();
            cardPreview.setData(text(fromInput), text(toInput), text(messageInput), palettes[themeIndex], selectedPhoto);
        }
    }
    private String text(EditText e) { return e == null ? "" : e.getText().toString().trim(); }

    private Bitmap renderBitmap() {
        refreshCard();
        int w = 1080, h = 1350;
        Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        cardPreview.drawCard(canvas, w, h);
        return bitmap;
    }

    private void saveCard() {
        try {
            Bitmap bitmap = renderBitmap();
            String fileName = "RomanticCard_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".jpg";
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RomanticCards");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("تعذر إنشاء ملف الصورة");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            }
            Toast.makeText(this, "تم حفظ البطاقة في معرض الصور ❤️", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "تعذر حفظ البطاقة: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareCard() {
        try {
            Bitmap bitmap = renderBitmap();
            File dir = new File(getCacheDir(), "cards");
            if (!dir.exists()) dir.mkdirs();
            File file = new File(dir, "romantic_card.jpg");
            try (FileOutputStream out = new FileOutputStream(file)) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out);
            }
            Uri uri = FileProvider.getUriForFile(this, "com.khaledsoot.romanticcard.provider", file);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/jpeg");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "مشاركة البطاقة الرومانسية"));
        } catch (Exception ex) {
            Toast.makeText(this, "تعذرت مشاركة البطاقة: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private class CardPreview extends View {
        private String from = "خالد", to = "منيا", message = "أنتِ أجمل أقداري ❤️";
        private int[] colors = palettes[0];
        private Bitmap photo;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        CardPreview() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void setData(String f, String t, String m, int[] c, Bitmap image) { from=f; to=t; message=m; colors=c; photo=image; invalidate(); }
        @Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); drawCard(canvas, getWidth(), getHeight()); }
        void drawCard(Canvas canvas, int width, int height) {
            float scale = Math.min(width / 1080f, height / 1350f);
            canvas.save();
            canvas.scale(scale, scale);
            float w = 1080, h = 1350;
            p.setShader(new LinearGradient(0, 0, w, h, colors[0], colors[1], Shader.TileMode.CLAMP));
            canvas.drawRoundRect(new RectF(0,0,w,h), 54,54,p);
            p.setShader(null);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(8); p.setColor(Color.argb(180,255,220,230));
            canvas.drawRoundRect(new RectF(34,34,w-34,h-34), 42,42,p); p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.argb(75,255,255,255)); p.setTextSize(150);
            canvas.drawText("♥", 170, 230, p); canvas.drawText("♥", 900, 1120, p); canvas.drawText("✦", 890, 260, p); canvas.drawText("✦", 190, 1080, p);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.create("serif", Typeface.BOLD)); p.setTextSize(82);
            canvas.drawText("إلى القلب الذي أحب", w/2, 300, p);
            if (photo != null && !photo.isRecycled()) {
                float cx = w / 2f, cy = 485, radius = 145;
                p.setColor(Color.argb(100, 255, 255, 255));
                canvas.drawCircle(cx, cy, radius + 13, p);
                int save = canvas.save();
                Path clip = new Path(); clip.addCircle(cx, cy, radius, Path.Direction.CW);
                canvas.clipPath(clip);
                float scalePhoto = Math.max((radius * 2) / photo.getWidth(), (radius * 2) / photo.getHeight());
                float dw = photo.getWidth() * scalePhoto, dh = photo.getHeight() * scalePhoto;
                RectF dst = new RectF(cx - dw/2, cy - dh/2, cx + dw/2, cy + dh/2);
                p.setColor(Color.WHITE); canvas.drawBitmap(photo, null, dst, p);
                canvas.restoreToCount(save);
            } else {
                p.setTextSize(118); canvas.drawText("♥", w/2, 485, p);
            }
            p.setColor(Color.WHITE); p.setTextSize(78); canvas.drawText(to.isEmpty()?"إلى من تحب":to, w/2, 690, p);
            p.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); p.setTextSize(49);
            drawWrapped(canvas, message.isEmpty()?"اكتب رسالتك الجميلة هنا":message, w/2, 820, 850, 68);
            p.setTextSize(48); p.setTypeface(Typeface.create("serif", Typeface.ITALIC));
            canvas.drawText("مع كل الحب،", w/2, 1120, p);
            p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(64); canvas.drawText(from.isEmpty()?"اسم المرسل":from, w/2, 1205, p);
            p.setTypeface(Typeface.DEFAULT); p.setTextSize(32); p.setColor(Color.argb(220,255,235,240));
            canvas.drawText("Khaled Soot", w/2, 1290, p);
            canvas.restore();
        }
        private void drawWrapped(Canvas canvas, String value, float centerX, float y, float maxWidth, float lineHeight) {
            String[] words = value.split("\\s+");
            java.util.ArrayList<String> lines = new java.util.ArrayList<>();
            String line = "";
            p.setTextSize(49);
            for (String word : words) {
                String candidate = line.isEmpty()?word:line+" "+word;
                if (p.measureText(candidate) > maxWidth && !line.isEmpty()) { lines.add(line); line=word; }
                else line=candidate;
            }
            if (!line.isEmpty()) lines.add(line);
            int maxLines = 4;
            for (int i=0; i<Math.min(lines.size(),maxLines); i++) canvas.drawText(lines.get(i), centerX, y+i*lineHeight, p);
        }
    }
}
